import { Router, type IRouter } from "express";
import healthRouter from "./health";
import agrihubRouter from "./agrihub";

const router: IRouter = Router();

router.use(healthRouter);
router.use(agrihubRouter);

export default router;
