import { Router, type IRouter } from 'express';
import {
  agriHubHardware,
  appModeSchema,
  deviceRegistrationSchema,
  HardwareError,
  heartbeatSchema,
  modeRequestSchema,
  pumpCommandSchema,
  sensorPayloadSchema,
} from '../hardware/agrihub-hardware';

const router: IRouter = Router();

function sendValidationError(res: Parameters<IRouter['get']>[1] extends never ? never : any, detail: string) {
  res.status(400).json({ title: 'Invalid request', detail });
}

function sendHardwareError(res: any, error: unknown) {
  if (error instanceof HardwareError) {
    res.status(error.status).json({ title: error.code, detail: error.message });
    return;
  }
  res.status(500).json({ title: 'Hardware operation failed', detail: 'The hardware operation could not be completed.' });
}

router.get('/sensor-data/latest', (_req, res) => {
  res.json(agriHubHardware.getLatest());
});

router.post('/sensor-data', (req, res) => {
  const parsed = sensorPayloadSchema.safeParse(req.body);
  if (!parsed.success) {
    sendValidationError(res, parsed.error.message);
    return;
  }
  try {
    res.json(agriHubHardware.ingest(parsed.data));
  } catch (error) {
    sendHardwareError(res, error);
  }
});

router.get('/device/status', (_req, res) => {
  res.json(agriHubHardware.getDeviceStatus());
});

router.get('/device/mode', (_req, res) => {
  res.json({ mode: agriHubHardware.getMode() });
});

router.put('/device/mode', (req, res) => {
  const parsed = modeRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    sendValidationError(res, parsed.error.message);
    return;
  }
  agriHubHardware.setMode(parsed.data.mode);
  res.json({ mode: agriHubHardware.getMode() });
});

router.post('/device/register', (req, res) => {
  const parsed = deviceRegistrationSchema.safeParse(req.body);
  if (!parsed.success) {
    sendValidationError(res, parsed.error.message);
    return;
  }
  res.json(agriHubHardware.registerDevice(parsed.data));
});

router.post('/device/heartbeat', (req, res) => {
  const parsed = heartbeatSchema.safeParse(req.body);
  if (!parsed.success) {
    sendValidationError(res, parsed.error.message);
    return;
  }
  try {
    res.json(agriHubHardware.heartbeat(parsed.data.device_id));
  } catch (error) {
    sendHardwareError(res, error);
  }
});

router.post('/pump/command', (req, res) => {
  const parsed = pumpCommandSchema.safeParse(req.body);
  if (!parsed.success) {
    sendValidationError(res, parsed.error.message);
    return;
  }
  try {
    res.json(agriHubHardware.sendPumpCommand(parsed.data));
  } catch (error) {
    sendHardwareError(res, error);
  }
});

router.get('/recommendations', (_req, res) => {
  const latest = agriHubHardware.getLatest();
  if (!latest) {
    res.json({ generated_at: new Date().toISOString(), items: [] });
    return;
  }
  res.json({
    generated_at: new Date().toISOString(),
    items: [
      { id: 'irrigate', icon: 'droplet', title: 'Irrigate Today', detail: 'Soil moisture is at ' + latest.soil_moisture + '%, below the preferred range for this field.', priority: latest.soil_moisture < 35 ? 'high' : 'low' },
      { id: 'fertilizer', icon: 'sprout', title: 'Fertilizer Recommendation', detail: 'Apply a light nitrogen feed after irrigation and avoid overwatering.', priority: 'medium' },
      { id: 'spraying', icon: 'slash', title: 'Avoid Pesticide Spraying Tomorrow', detail: 'Strong wind is expected. Recheck conditions before spraying.', priority: 'medium' },
      { id: 'pest-check', icon: 'search', title: 'Check Crop for Pest Activity', detail: 'Pest risk is ' + latest.pest_activity + '. Inspect the underside of leaves this evening.', priority: latest.pest_activity === 'high' ? 'high' : 'low' },
    ],
  });
});

router.get('/alerts', (_req, res) => {
  const latest = agriHubHardware.getLatest();
  if (!latest) {
    res.json({ items: [] });
    return;
  }
  res.json({
    items: [
      { id: 'soil-low', severity: latest.soil_moisture < 35 ? 'warning' : 'info', title: 'Soil moisture is ' + (latest.soil_moisture < 35 ? 'low' : 'healthy'), detail: latest.soil_moisture < 35 ? 'Irrigation is recommended today for the north field.' : 'No immediate irrigation issue detected.', time_label: 'Now', resolved: false },
      { id: 'wind', severity: 'info', title: 'Strong wind tomorrow', detail: 'Avoid pesticide spraying until wind conditions settle.', time_label: 'Today', resolved: false },
      { id: 'pest', severity: latest.pest_activity === 'high' ? 'critical' : 'warning', title: latest.pest_activity + ' pest risk', detail: 'Inspect crops for early signs of activity.', time_label: 'Today', resolved: false },
    ],
  });
});

router.get('/weather', (_req, res) => {
  res.json({
    location: 'Your farm',
    current: '34°C · Clear',
    forecast: [
      { day: 'Today', label: 'Clear', high: 35, low: 26, icon: 'sun' },
      { day: 'Tomorrow', label: 'Windy', high: 33, low: 25, icon: 'wind' },
      { day: 'Wed', label: 'Light rain', high: 31, low: 24, icon: 'cloud-rain' },
    ],
  });
});

export default router;
