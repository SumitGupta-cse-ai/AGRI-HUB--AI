import { z } from 'zod/v4';

export const appModeSchema = z.enum(['demo', 'hardware']);
export type AppMode = z.infer<typeof appModeSchema>;

export const sensorPayloadSchema = z.object({
  device_id: z.string().min(1).max(64),
  timestamp: z.string().datetime().optional(),
  soil_moisture: z.number().min(0).max(100),
  temperature: z.number().min(-50).max(80),
  humidity: z.number().min(0).max(100),
  rain_detected: z.boolean(),
  water_flow: z.number().min(0).max(10000),
  wind_speed: z.number().min(0).max(300),
  pest_activity: z.enum(['low', 'medium', 'high']),
});
export type SensorPayload = z.infer<typeof sensorPayloadSchema>;
export type SensorData = Omit<SensorPayload, 'timestamp'> & { timestamp: string };

export const deviceRegistrationSchema = z.object({
  device_id: z.string().min(1).max(64),
  name: z.string().min(1).max(100),
  model: z.string().min(1).max(100),
  sensors: z.array(z.string().min(1)).min(1),
});
export type DeviceRegistration = z.infer<typeof deviceRegistrationSchema>;

export const heartbeatSchema = z.object({
  device_id: z.string().min(1).max(64),
  timestamp: z.string().datetime().optional(),
});

export const modeRequestSchema = z.object({ mode: appModeSchema });

export const pumpCommandSchema = z.object({
  device_id: z.string().min(1).max(64),
  action: z.enum(['on', 'off']),
  confirmed: z.boolean(),
});
export type PumpCommand = z.infer<typeof pumpCommandSchema>;

export type PumpState = 'on' | 'off' | 'unknown';

export class HardwareError extends Error {
  constructor(public readonly code: string, message: string, public readonly status = 400) {
    super(message);
    this.name = 'HardwareError';
  }
}

const defaultDevice: DeviceRegistration = {
  device_id: 'agrihub-esp32-01',
  name: 'AgriHub Gateway',
  model: 'ESP32',
  sensors: ['Soil Moisture', 'Temperature', 'Humidity', 'Rain', 'Water Flow', 'Wind', 'Camera/Pest Node'],
};

const demoData: SensorData = {
  device_id: defaultDevice.device_id,
  timestamp: new Date().toISOString(),
  soil_moisture: 27,
  temperature: 34.2,
  humidity: 61,
  rain_detected: false,
  water_flow: 0,
  wind_speed: 12,
  pest_activity: 'medium',
};

const HEARTBEAT_TIMEOUT_MS = Number(process.env.AGRIHUB_HEARTBEAT_TIMEOUT_MS ?? 90_000);

class AgriHubHardwareAbstraction {
  private mode: AppMode = 'demo';
  private readonly devices = new Map<string, DeviceRegistration>([[defaultDevice.device_id, defaultDevice]]);
  private latestHardwareData: SensorData | null = null;
  private lastHeartbeat: number | null = null;
  private pumpState: PumpState = 'off';

  setMode(mode: AppMode): void {
    this.mode = mode;
    if (mode === 'demo') this.lastHeartbeat = Date.now();
  }

  getMode(): AppMode {
    return this.mode;
  }

  getLatest(): SensorData | null {
    if (this.mode === 'demo') return { ...demoData };
    return this.isHardwareOnline() ? this.latestHardwareData : null;
  }

  registerDevice(registration: DeviceRegistration) {
    this.devices.set(registration.device_id, registration);
    return { ...registration, acknowledged: true, registered_at: new Date().toISOString() };
  }

  heartbeat(deviceId: string) {
    this.assertKnownDevice(deviceId);
    this.lastHeartbeat = Date.now();
    return { acknowledged: true, device_id: deviceId, timestamp: new Date().toISOString() };
  }

  ingest(payload: SensorPayload): SensorData {
    this.assertKnownDevice(payload.device_id);
    const data: SensorData = { ...payload, timestamp: payload.timestamp ?? new Date().toISOString() };
    this.latestHardwareData = data;
    this.lastHeartbeat = Date.now();
    return data;
  }

  getDeviceStatus() {
    const connected = this.mode === 'demo' || this.isHardwareOnline();
    const device = this.devices.get(defaultDevice.device_id) ?? defaultDevice;
    return {
      device_id: device.device_id,
      name: device.name,
      model: device.model,
      mode: this.mode,
      connected,
      last_seen: this.mode === 'demo' ? new Date().toISOString() : this.lastHeartbeat ? new Date(this.lastHeartbeat).toISOString() : null,
      connection_label: connected ? 'Connected' : 'Offline',
      sensors: device.sensors,
      pump_state: this.mode === 'hardware' && !connected ? 'unknown' : this.pumpState,
    };
  }

  sendPumpCommand(command: PumpCommand) {
    this.assertKnownDevice(command.device_id);
    if (command.action === 'on' && !command.confirmed) {
      throw new HardwareError('PUMP_CONFIRMATION_REQUIRED', 'Pump activation requires explicit confirmation.', 400);
    }
    if (this.mode === 'hardware' && !this.isHardwareOnline()) {
      throw new HardwareError('GATEWAY_OFFLINE', 'Cannot send a pump command while the gateway is offline.', 409);
    }
    if (this.mode === 'hardware' && process.env.AGRIHUB_HARDWARE_SIMULATOR !== 'true') {
      throw new HardwareError('HARDWARE_TRANSPORT_NOT_CONFIGURED', 'The ESP32 command transport is not configured yet.', 503);
    }
    this.pumpState = command.action;
    return {
      accepted: true,
      device_id: command.device_id,
      action: command.action,
      pump_state: this.pumpState,
      acknowledged_at: new Date().toISOString(),
      transport: this.mode === 'demo' ? 'demo-simulator' : 'hardware-simulator',
    };
  }

  private isHardwareOnline(): boolean {
    return this.lastHeartbeat !== null && Date.now() - this.lastHeartbeat < HEARTBEAT_TIMEOUT_MS;
  }

  private assertKnownDevice(deviceId: string): void {
    if (!this.devices.has(deviceId)) throw new HardwareError('UNKNOWN_DEVICE', 'Device must register before sending data.', 409);
  }
}

export const agriHubHardware = new AgriHubHardwareAbstraction();
export const agriHubDefaults = { deviceId: defaultDevice.device_id, heartbeatTimeoutMs: HEARTBEAT_TIMEOUT_MS };
