const colors = {
  light: {
    text: '#f4f7f2', tint: '#9acb72', background: '#101512', foreground: '#f4f7f2',
    card: '#182019', cardForeground: '#f4f7f2', primary: '#9acb72', primaryForeground: '#10200f',
    secondary: '#243025', secondaryForeground: '#f4f7f2', muted: '#243025', mutedForeground: '#9aa79a',
    accent: '#31482e', accentForeground: '#d9f5c0', destructive: '#ef8f6c', destructiveForeground: '#29140d',
    border: '#2b382c', input: '#263227',
  },
  radius: 18,
};
export default colors;
