import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
export type AppMode = 'demo' | 'hardware';
type AppContextValue = { mode: AppMode; setMode: (mode: AppMode) => void; isReady: boolean };
const AppContext = createContext<AppContextValue | null>(null);
const MODE_KEY = 'agrihub-mode';
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [mode, setModeState] = useState<AppMode>('demo');
  const [isReady, setIsReady] = useState(false);
  useEffect(() => { AsyncStorage.getItem(MODE_KEY).then((stored) => { if (stored === 'demo' || stored === 'hardware') setModeState(stored); }).finally(() => setIsReady(true)); }, []);
  const value = useMemo(() => ({ mode, isReady, setMode: (nextMode: AppMode) => { setModeState(nextMode); void AsyncStorage.setItem(MODE_KEY, nextMode); } }), [isReady, mode]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useAppContext() { const context = useContext(AppContext); if (!context) throw new Error('useAppContext must be used inside AppProvider'); return context; }
