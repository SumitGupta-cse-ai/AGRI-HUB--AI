# AgriHub – AI Smart Farming Assistant

AgriHub is a mobile-first smart farming assistant that reads field telemetry through a REST API, turns it into practical recommendations and alerts, and provides a demo-ready AgriBot assistant.

## Run

- `pnpm --filter @workspace/api-server run dev` — run the API server.
- `pnpm --filter @workspace/agrihub run dev` — run the Expo app for Android and web.
- `pnpm run typecheck` — check all workspace packages.
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas after changing the API contract.

The managed workflows inject ports and preview routing. The Expo client uses `EXPO_PUBLIC_DOMAIN` for its API base URL, so no frontend host is hardcoded.

## Product

- Home dashboard with gateway status, live sensor summary, weather context, field health, recommendations, and AgriBot entry point.
- Live Field screen with auto-refreshing sensor readings and weather outlook.
- AgriBot screen with practical demo answers grounded in the latest API reading.
- Alerts screen for irrigation, wind, and pest-risk items.
- Settings screen with persisted Demo Mode / Real Hardware Mode selection.
- Gateway screen with heartbeat-backed connection status and sensor reporting list.

## API endpoints

- `GET /api/sensor-data/latest` — latest field sensor reading.
- `POST /api/sensor-data` — ESP32 telemetry payload; updates the gateway heartbeat.
- `GET /api/device/status` — gateway connection and sensor list.
- `GET /api/recommendations` — today's recommendation list.
- `GET /api/alerts` — active alerts.
- `GET /api/weather` — current and forecast weather.
- `GET /api/healthz` — server health.

## Demo backend behavior

The demo backend starts with realistic simulated sensor data. The UI still receives those values through the REST API; sensor fixtures are not embedded in the frontend.

The gateway is reported as `Connected` only while the backend has received telemetry within the last 90 seconds. The current store is intentionally in-memory so the first build runs without database setup. SQLite persistence can replace that store later without changing the API paths.

## ESP32 handoff

The future ESP32 hub should send this JSON payload to `POST /api/sensor-data` over Wi-Fi:

```json
{
  "device_id": "agrihub-esp32-01",
  "soil_moisture": 27,
  "temperature": 34.2,
  "humidity": 61,
  "rain_detected": false,
  "water_flow": 0,
  "wind_speed": 12,
  "pest_activity": "medium"
}
```

No GPIO assignments are included yet. The exact sensors will be selected later; the app currently depends only on the JSON field names and REST contract.

## Important paths

- `artifacts/agrihub/` — Expo Android/web app.
- `artifacts/agrihub/app/(tabs)/` — Home, Live Field, AgriBot, Alerts, and Settings.
- `artifacts/agrihub/app/device.tsx` — gateway and sensor status.
- `artifacts/agrihub/context/app-context.tsx` — persisted app mode.
- `artifacts/api-server/src/routes/agrihub.ts` — demo telemetry, heartbeat, weather, recommendations, and alerts.
- `lib/api-spec/openapi.yaml` — REST contract source of truth.
- `lib/api-client-react/src/generated/` — generated hooks consumed by Expo.