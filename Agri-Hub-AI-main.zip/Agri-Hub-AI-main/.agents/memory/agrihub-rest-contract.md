---
name: AgriHub REST-first demo boundary
description: Durable boundary between the runnable demo and later hardware and persistence work.
---

The first AgriHub build keeps simulated telemetry in the API layer, not in the mobile UI, and exposes the same REST payload shape intended for the future ESP32 gateway.

**Why:** This makes Demo Mode immediately runnable while keeping the frontend independent from the eventual sensor transport and storage choice.

**How to apply:** Preserve the existing REST paths and JSON fields when adding SQLite history, real ESP32 heartbeats, or AI context; replace the store behind the API rather than embedding hardware-specific logic in screens.
